package no.kristiania.product.screens.UI_beginning

// Som nevnt fra productDesignPreview var dette for å teste ut previewdesign som jeg glemte å kopiere og lime det inn i ny kt.file
// Mocklist
/*
val productList = listOf(
    Product(
        id = 1,
        title = "Fjallraven - Foldsack No. 1 Backpack, Fits 15 Laptops",
        category = "men's clothing",
        price = 109.95,
        image = "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg"
    ),
    Product(
        id = 2,
        title = "Mens Casual Premium Slim Fit T-Shirts ",
        category = "jewerly",
        price = 22.3,
        image = ""
    )
)*/